const ReviewsPage = () => {
  return <div>ReviewsPage</div>;
};

export default ReviewsPage;
