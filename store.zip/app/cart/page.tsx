const CartPage = () => {
  return <div>CartPage</div>;
};

export default CartPage;
