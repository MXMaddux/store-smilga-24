"use client";

import dynamic from "next/dynamic";
import LoadingContainer from "@/components/global/LoadingContainer";
import Hero from "@/components/home/Hero";
import { Suspense } from "react";

const FeaturedProducts = dynamic(
  () => import("@/components/home/FeaturedProducts"),
  {
    ssr: false, // Disable server-side rendering
    loading: () => <LoadingContainer />,
  }
);

export default function HomePage() {
  return (
    <>
      <Hero />
      <Suspense fallback={<LoadingContainer />}>
        <FeaturedProducts />
      </Suspense>
    </>
  );
}
