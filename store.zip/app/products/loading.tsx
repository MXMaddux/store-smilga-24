"use client";

import LoadingContainer from "@/components/global/LoadingContainer";

const loading = () => {
  return <LoadingContainer />;
};

export default loading;
