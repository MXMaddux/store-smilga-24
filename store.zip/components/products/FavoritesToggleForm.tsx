function FavoritesToggleForm() {
  return <div>FavoritesToggleForm</div>;
}
export default FavoritesToggleForm;
