const UserIcon = () => {
  return <div>UserIcon</div>;
};

export default UserIcon;
