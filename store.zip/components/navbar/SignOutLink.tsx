const SignOutLink = () => {
  return <div>SignOutLink</div>;
};

export default SignOutLink;
